Name: Alan Han
Email: han300@purdue.edu
Phone: 6307310174
Date: 04/06/2016
Board Name: minesweeper2

X: 73.01mm
Y: 53.01mm

Area: 3870.2601 sq mm